@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul

REM ============================================================
REM Mustatil Qt Workspace - Dependency Installer for Python 3.12
REM Creates/uses local .venv and fixes common NumPy/Torch issues.
REM ============================================================

cd /d "%~dp0"

echo.
echo ============================================================
echo Checking Python 3.12
echo ============================================================

where py >nul 2>nul
if errorlevel 1 (
    echo ERROR: Windows Python launcher "py" was not found.
    echo Install Python 3.12 from python.org and enable "py launcher".
    pause
    exit /b 1
)

py -3.12 -c "import sys; print(sys.executable); print(sys.version)" >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python 3.12 was not found by py -3.12.
    echo Install Python 3.12 or repair the Python installation.
    pause
    exit /b 1
)

set "PY=py -3.12"
set "VENV=.venv"
set "VPY=%CD%\%VENV%\Scripts\python.exe"

echo.
echo ============================================================
echo Creating/using virtual environment: %VENV%
echo ============================================================

if not exist "%VPY%" (
    %PY% -m venv "%VENV%"
    if errorlevel 1 (
        echo ERROR: Could not create virtual environment.
        pause
        exit /b 1
    )
)

echo.
echo ============================================================
echo Upgrading pip/setuptools/wheel
echo ============================================================
"%VPY%" -m pip install --upgrade pip setuptools wheel
if errorlevel 1 goto :pip_error

echo.
echo ============================================================
echo Cleaning broken NumPy installs
echo ============================================================
"%VPY%" -m pip uninstall -y numpy numpy-base >nul 2>nul
"%VPY%" -m pip cache purge >nul 2>nul

echo.
echo ============================================================
echo Installing stable NumPy first: numpy==1.26.4
echo ============================================================
"%VPY%" -m pip install --no-cache-dir "numpy==1.26.4"
if errorlevel 1 goto :pip_error

echo.
echo ============================================================
echo Installing PyTorch CPU runtime
echo ============================================================
REM CPU wheels are most reliable for installer/runtime use.
REM For CUDA GPU training, install the matching CUDA torch wheel separately from pytorch.org.
"%VPY%" -m pip install --no-cache-dir torch torchvision --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 goto :pip_error

echo.
echo ============================================================
echo Installing Mustatil GUI / YOLO dependencies
echo ============================================================
"%VPY%" -m pip install --no-cache-dir ^
    PySide6 ^
    Pillow ^
    requests ^
    ultralytics ^
    opencv-python-headless ^
    tqdm ^
    tifffile ^
    shapely ^
    pyproj ^
    fiona ^
    geopandas ^
    rasterio
if errorlevel 1 goto :pip_error

echo.
echo ============================================================
echo Verifying imports
echo ============================================================
"%VPY%" - <<PYTEST
import sys
print("Python:", sys.version)
mods = [
    "numpy", "PIL", "PySide6", "requests", "torch", "torchvision",
    "ultralytics", "cv2", "tifffile", "shapely", "pyproj",
    "fiona", "geopandas", "rasterio"
]
failed = []
for m in mods:
    try:
        mod = __import__(m)
        ver = getattr(mod, "__version__", "OK")
        print(f"OK: {m} {ver}")
    except Exception as exc:
        failed.append((m, str(exc)))
        print(f"FAILED: {m}: {exc}")
if failed:
    raise SystemExit(1)
PYTEST
if errorlevel 1 (
    echo.
    echo IMPORT TEST FAILED.
    echo Try deleting the .venv folder and run this installer again.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo DONE
echo ============================================================
echo Dependencies installed in:
echo %VPY%
echo.
echo Start your app with this Python, for example:
echo "%VPY%" mustatil_qt_workspace.py
echo.
pause
exit /b 0

:pip_error
echo.
echo ============================================================
echo PIP INSTALL FAILED
echo ============================================================
echo 1^) Check your internet connection.
echo 2^) Delete the .venv folder and run this BAT again.
echo 3^) Make sure Python 3.12 64-bit is installed.
echo.
pause
exit /b 1
