#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Detection preview helper for Mustatil Qt Workspace.

This module is intentionally separate from the main Qt window. The main GUI
keeps the QGraphicsView in the Detection tab, while this helper decides which
preview/pyramid level should be loaded for the current zoom and loads TIFF
previews via rasterio when available.
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable, Optional, Tuple

from PIL import Image


TIFF_EXTENSIONS = (".tif", ".tiff")


def is_tiff_path(path: str) -> bool:
    return str(path or "").lower().endswith(TIFF_EXTENSIONS)


def compute_zoom_preview_max(
    zoom: float,
    base_max: int = 2400,
    current_max: int = 2400,
    hard_max: int = 12000,
    reload_factor: float = 1.20,
) -> Optional[int]:
    """Return a new preview max size if the current zoom needs a sharper level.

    Returning None means the existing preview is still sharp enough.
    """
    try:
        z = max(1.0, float(zoom or 1.0))
        base = max(512, int(base_max or 2400))
        current = max(1, int(current_max or base))
        hard = max(base, int(hard_max or 12000))
        target = int(min(hard, max(base, base * z)))
        if target <= int(current * float(reload_factor or 1.20)):
            return None
        return target
    except Exception:
        return None


def load_detection_preview_image(
    path: str,
    maxs: int = 2400,
    fallback_loader: Optional[Callable[..., Tuple[Image.Image, int, int]]] = None,
) -> Tuple[Image.Image, int, int]:
    """Load a downsampled preview and return (PIL image, original width, original height).

    For TIFF/GeoTIFF this uses rasterio overviews/pyramids when possible. For
    non-TIFF images, or if rasterio is unavailable/fails, the provided fallback
    loader is used. The main program passes backend.load_preview as fallback.
    """
    p = str(path or "").strip()
    if not p:
        raise RuntimeError("No image path supplied for detection preview.")
    maxs = max(512, int(maxs or 2400))

    if not is_tiff_path(p):
        if fallback_loader is None:
            im = Image.open(p).convert("RGB")
            w, h = im.size
            im.thumbnail((maxs, maxs), Image.Resampling.LANCZOS)
            return im.copy(), w, h
        return fallback_loader(p, maxs=maxs)

    try:
        import numpy as np
        import rasterio
        from rasterio.enums import Resampling

        with rasterio.open(p) as src:
            w, h = int(src.width), int(src.height)
            scale = min(1.0, float(maxs) / float(max(w, h)))
            out_w = max(1, int(round(w * scale)))
            out_h = max(1, int(round(h * scale)))
            count = min(3, int(src.count))
            if count <= 0:
                raise RuntimeError("TIFF contains no readable raster bands.")
            arr = src.read(
                list(range(1, count + 1)),
                out_shape=(count, out_h, out_w),
                resampling=Resampling.nearest,
            )
            arr = np.asarray(arr)
            if arr.dtype != np.uint8:
                arr = arr.astype("float32")
                finite = np.isfinite(arr)
                if finite.any():
                    lo = float(np.nanpercentile(arr[finite], 1))
                    hi = float(np.nanpercentile(arr[finite], 99))
                    if hi <= lo:
                        hi = lo + 1.0
                    arr = (np.clip((arr - lo) / (hi - lo), 0, 1) * 255).astype("uint8")
                else:
                    arr = np.zeros_like(arr, dtype="uint8")
            if count == 1:
                im = Image.fromarray(arr[0], mode="L").convert("RGB")
            else:
                im = Image.fromarray(np.transpose(arr[:3], (1, 2, 0)), mode="RGB")
            return im, w, h
    except Exception:
        if fallback_loader is not None:
            return fallback_loader(p, maxs=maxs)
        im = Image.open(p).convert("RGB")
        w, h = im.size
        im.thumbnail((maxs, maxs), Image.Resampling.LANCZOS)
        return im.copy(), w, h
