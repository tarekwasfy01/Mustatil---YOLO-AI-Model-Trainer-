Mustatil Qt Workspace
=====================

This package contains a new PySide6/Qt frontend for the existing Mustatil GUI.
The original Tkinter backend is included as mustatil_legacy_backend.py and can
still be launched with START_LEGACY_TK_GUI.bat.

Start:
1. Run INSTALL_QT_DEPENDENCIES.bat once.
2. Run START_MUSTATIL_QT.bat.

New Qt features:
- QGIS/Word-style menu bar.
- Main toolbar.
- Project Browser dock.
- Layers dock.
- Central image workspace.
- Console/log dock.
- .mustatil project save/load file.
- Autosave file: .autosave.mustatil.
- Project folders: images, labels, crops, sam2, exports, weights, runs, logs, trained_form_models.

Compatibility:
- Detection, crop export, GeoPackage/GeoJSON export, YOLO training, SAM2, FormTrainer and
  FormLearner backend methods are reused from the previous Python file.
- The old GUI is included as fallback because some pixel-level manual annotation interactions
  are still richer in the Tkinter version.

Notes:
- PySide6 gives the QGIS-like UI foundation. QGIS itself is Qt-based.
- For very large GeoTIFFs, keep using the tiled/chunked workflow already in the backend.


Update v1.1
-----------
- FormLearner Detection is now integrated directly into the Detection tab.
- The Detection menu now contains "Start FormLearner Detection".
- The toolbar now contains a "Detect+Form" shortcut.
- The separate FormLearner Detection tab is no longer opened by default; the old method remains in code as fallback.
- __pycache__ files are not included in this ZIP.

Update v1.2:
- Low-RAM stable/stability mode is unchecked by default in the Qt workspace and legacy fallback GUI.

Version 1.3 Light Square UI
---------------------------
- Qt interface now uses a bright Office/QGIS-like theme.
- Buttons, tabs, group boxes and panels are square-edged.
- Dark canvas background was replaced by a light neutral workspace background.
- Low-RAM stable mode remains unchecked by default.


Version v1.4:
- The second top toolbar row with Open/Save/Preview/Detect/Export was removed.
- The main menu bar remains fully available.

Version v1.5:
- Added extra post-detection filter sliders directly inside the Detection tab.
- New sliders: Confidence filter, FormScore filter, Ensemble score filter, Minimum consensus.
- These filters redraw existing detections and affect visible exports/crops without starting YOLO again.
- The top toolbar remains removed; light square UI remains unchanged.

v1.6 changes:
- Annotator now has a Legacy-style annotation list for the current image.
- Added buttons: Set selected class, Delete selected box, Delete all / neutral, Reset from manifest box, Save annotation, Reload current.
- Project image list and current annotation list are separated.

Version 1.7 changes
-------------------
- Annotator: left mouse drag now draws a rectangle directly on the image.
- The rectangle is displayed live while dragging.
- Releasing the mouse adds the rectangle as a YOLO annotation with the currently selected class and saves it.
- Detection preview: reverted to a normal single overview preview without pyramid reloads.
- Mouse-wheel zoom now only scales the already loaded preview image.


Version 1.8 changes
-------------------
- The complete Qt menu UI is now English.
- SAM2 now uses all available boxes from the current annotator state or YOLO label files as prompt boxes.
- The SAM2 preview now displays every prompt box instead of failing on 4-value boxes.
- The Annotator tab now has a bottom button for SAM2 segmentation of all annotated/project images.
- Qt-native SAM2 task methods replace legacy Tk after-callbacks, so batch SAM2 works correctly in the Qt workspace.


Version 1.9 changes:
- Detection overview preview no longer reloads raster pyramids/overviews during zoom.
- Removed the Zoom + / reload detail and Zoom - / reload overview buttons.
- Annotator mouse rectangle drawing and SAM2 label-box prompting remain unchanged.

Version v1.10:
- YOLO Trainer now has a selectable "Model output folder" field.
- Training writes Ultralytics runs to the selected folder as <output>/train_mustatil/weights/best.pt.
- Resume and ONNX export use the selected output folder first, with backward-compatible fallback to <project>/runs.
- The selected output folder is saved in the .mustatil project file as train_output_folder.

v1.11 Auto annotate crops
- Annotator tab: added an "Auto annotate crops" block with FormLearner model picker, FormScore threshold and a start button.
- Auto annotate crops reruns the selected YOLO model(s) over every crop image at confidence 0.001.
- Every YOLO detection is scored by the selected FormLearner model. FormScore >= threshold is written as class 0 / positive; lower FormScore is written as class 1 / false-positive/negative.
- The same auto-detected boxes are sent to SAM2 and saved as per-crop .sam2.json sidecar files.
- Per-crop audit metadata is saved as .auto_annotate.json next to each crop image.
