#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Separate Mustatil GitHub auto-updater GUI.

Place this file next to mustatil_qt_workspace.py. The main workspace only
starts this script in a separate process/window.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    from PySide6.QtCore import Signal, QObject
    from PySide6.QtWidgets import (
        QApplication, QWidget, QVBoxLayout, QHBoxLayout,
        QLabel, QPushButton, QTextEdit, QMessageBox, QComboBox, QGroupBox
    )
except Exception as exc:
    raise SystemExit("PySide6 is missing. Start the Mustatil launcher so dependencies can be installed.\n" + str(exc))

APP_VERSION = "3.2.0"
CONFIG_NAME = "github_update_config.json"
DEFAULT_REPO = "tarekwasfy01/Mustatil---YOLO-AI-Model-Trainer-"
SETUP_EXTENSIONS = (".exe", ".msi")
SILENT_INNO_ARGS = ["/VERYSILENT", "/SUPPRESSMSGBOXES", "/NORESTART", "/SP-", "/MERGETASKS=desktopicon"]
SILENT_NSIS_ARGS = ["/S"]


@dataclass
class ReleaseInfo:
    tag: str = ""
    name: str = ""
    html_url: str = ""
    asset_name: str = ""
    asset_url: str = ""
    body: str = ""

    def display_name(self) -> str:
        label = self.tag or self.name or "Release"
        if self.asset_name:
            label += f"  ({self.asset_name})"
        return label


class Signals(QObject):
    log = Signal(str)
    releases_loaded = Signal(object)
    newer_check_done = Signal(object)
    install_done = Signal(str)
    error = Signal(str)


class AutoUpdaterWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Mustatil Auto Updater")
        self.resize(740, 440)
        self.base = Path(__file__).resolve().parent
        self.config_path = self.base / CONFIG_NAME
        self.repo = DEFAULT_REPO
        self.asset_pattern = ".exe"
        self.releases: List[ReleaseInfo] = []

        self.signals = Signals()
        self.signals.log.connect(self.log)
        self.signals.releases_loaded.connect(self.on_releases_loaded)
        self.signals.newer_check_done.connect(self.on_newer_check_done)
        self.signals.install_done.connect(self.on_install_done)
        self.signals.error.connect(lambda txt: QMessageBox.critical(self, "Auto Updater", txt))

        self._build_ui()
        self.load_config()
        self.refresh_releases()

    def _build_ui(self):
        root = QVBoxLayout(self)

        newest_box = QGroupBox("Newest Release")
        newest_row = QHBoxLayout(newest_box)
        newest_row.addWidget(QLabel("Download the newest GitHub release, run the installer automatically, and create a desktop shortcut:"), 1)
        self.check_newer_btn = QPushButton("Check for Newer Version")
        self.check_newer_btn.clicked.connect(self.check_for_newer_version)
        newest_row.addWidget(self.check_newer_btn)
        self.install_newest_btn = QPushButton("Install Newest Release")
        self.install_newest_btn.clicked.connect(self.install_newest_release)
        newest_row.addWidget(self.install_newest_btn)
        root.addWidget(newest_box)

        older_box = QGroupBox("Install Older Release")
        older_col = QVBoxLayout(older_box)
        older_row = QHBoxLayout()
        self.older_combo = QComboBox()
        self.older_combo.setMinimumWidth(420)
        older_row.addWidget(QLabel("Older Release:"))
        older_row.addWidget(self.older_combo, 1)
        self.refresh_btn = QPushButton("Refresh Releases")
        self.refresh_btn.clicked.connect(self.refresh_releases)
        older_row.addWidget(self.refresh_btn)
        self.install_older_btn = QPushButton("Install Older Release")
        self.install_older_btn.clicked.connect(self.install_older_release)
        older_row.addWidget(self.install_older_btn)
        older_col.addLayout(older_row)
        root.addWidget(older_box)

        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        root.addWidget(self.log_box, 1)

    def log(self, text: str):
        self.log_box.append(f"[{time.strftime('%H:%M:%S')}] {text}")

    def load_config(self):
        """Repo remains configurable through github_update_config.json, but not through the GUI."""
        if not self.config_path.is_file():
            self.save_config()
            self.log(f"No config found. Default repository set: {self.repo}")
            return
        try:
            cfg = json.loads(self.config_path.read_text(encoding="utf-8"))
            self.repo = str(cfg.get("repo", DEFAULT_REPO)).strip() or DEFAULT_REPO
            pattern = str(cfg.get("asset_pattern", ".exe")).strip().lower()
            self.asset_pattern = pattern or ".exe"
            self.log(f"Config loaded. Repository: {self.repo}")
        except Exception as exc:
            self.log(f"Config could not be read; using default repository: {exc}")

    def save_config(self):
        cfg = {
            "repo": self.repo,
            "current_version": APP_VERSION,
            "asset_pattern": self.asset_pattern,
            "install_dir": str(self.base),
        }
        self.config_path.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")

    def set_busy(self, busy: bool):
        self.install_newest_btn.setEnabled(not busy)
        self.check_newer_btn.setEnabled(not busy)
        self.install_older_btn.setEnabled(not busy and self.older_combo.count() > 0)
        self.refresh_btn.setEnabled(not busy)
        self.older_combo.setEnabled(not busy and self.older_combo.count() > 0)

    def refresh_releases(self):
        self.set_busy(True)
        self.log("Loading GitHub releases …")
        threading.Thread(target=self._refresh_releases_worker, daemon=True).start()

    def _refresh_releases_worker(self):
        try:
            releases = self.fetch_releases()
            self.signals.releases_loaded.emit(releases)
        except Exception:
            self.signals.error.emit(traceback.format_exc())
            self.signals.releases_loaded.emit([])

    def github_get_json(self, url: str) -> Any:
        req = urllib.request.Request(url, headers={"User-Agent": "MustatilAutoUpdater/1.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8", errors="replace"))

    def fetch_releases(self) -> List[ReleaseInfo]:
        url = f"https://api.github.com/repos/{self.repo}/releases?per_page=50"
        data = self.github_get_json(url)
        releases: List[ReleaseInfo] = []
        for item in data:
            release = self.release_from_json(item)
            if release.asset_url:
                releases.append(release)
        return releases

    def release_from_json(self, data: Dict[str, Any]) -> ReleaseInfo:
        picked = self.pick_setup_asset(data.get("assets", []))
        return ReleaseInfo(
            tag=str(data.get("tag_name", "")),
            name=str(data.get("name", "")),
            html_url=str(data.get("html_url", "")),
            asset_name=str((picked or {}).get("name", "")),
            asset_url=str((picked or {}).get("browser_download_url", "")),
            body=str(data.get("body", "")),
        )

    def pick_setup_asset(self, assets: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        # Prefer installer/setup executable assets.
        for a in assets:
            name = str(a.get("name", "")).lower()
            if name.endswith(SETUP_EXTENSIONS) and ("setup" in name or "install" in name or "installer" in name):
                return a
        for a in assets:
            name = str(a.get("name", "")).lower()
            if name.endswith(SETUP_EXTENSIONS):
                return a
        # Fallback for older config patterns.
        pattern = self.asset_pattern.replace("*", "").lower()
        if pattern:
            for a in assets:
                if pattern in str(a.get("name", "")).lower():
                    return a
        return None

    def on_releases_loaded(self, releases_obj: object):
        self.releases = list(releases_obj or [])
        self.older_combo.clear()

        if not self.releases:
            self.log("No releases with setup EXE/MSI were found.")
            self.set_busy(False)
            return

        # Index 0 is newest. Older dropdown starts with index 1 if possible.
        older = self.releases[1:] if len(self.releases) > 1 else []
        for release in older:
            self.older_combo.addItem(release.display_name(), release)

        newest = self.releases[0]
        self.log(f"Newest release found: {newest.display_name()}")
        if older:
            self.log(f"Older releases in dropdown: {len(older)}")
        else:
            self.log("There is currently no older release available in the dropdown.")
        self.set_busy(False)

    def normalize_version_parts(self, text: str) -> List[int]:
        """Extract numeric version parts from tags like v3.1.2 or release-3.1."""
        import re
        nums = re.findall(r"\d+", text or "")
        return [int(x) for x in nums[:4]] or [0]

    def version_is_newer(self, latest: str, current: str) -> bool:
        a = self.normalize_version_parts(latest)
        b = self.normalize_version_parts(current)
        max_len = max(len(a), len(b))
        a += [0] * (max_len - len(a))
        b += [0] * (max_len - len(b))
        return a > b

    def check_for_newer_version(self):
        self.set_busy(True)
        self.log("Checking for a newer version …")
        threading.Thread(target=self._check_for_newer_version_worker, daemon=True).start()

    def _check_for_newer_version_worker(self):
        try:
            releases = self.fetch_releases()
            newest = releases[0] if releases else None
            self.signals.newer_check_done.emit(newest)
            self.signals.releases_loaded.emit(releases)
        except Exception:
            self.signals.error.emit(traceback.format_exc())
            self.signals.releases_loaded.emit(self.releases)

    def on_newer_check_done(self, release_obj: object):
        if not isinstance(release_obj, ReleaseInfo):
            self.log("No installable release was found.")
            QMessageBox.information(self, "Auto Updater", "No installable release was found.")
            return
        latest_label = release_obj.tag or release_obj.name or "unknown"
        if self.version_is_newer(latest_label, APP_VERSION):
            msg = f"A newer version is available: {latest_label}\nCurrent version: {APP_VERSION}"
            self.log(msg.replace("\n", " | "))
            QMessageBox.information(self, "Auto Updater", msg)
        else:
            msg = f"You are already on the newest known version.\nCurrent version: {APP_VERSION}\nNewest release: {latest_label}"
            self.log(msg.replace("\n", " | "))
            QMessageBox.information(self, "Auto Updater", msg)

    def install_newest_release(self):
        self.set_busy(True)
        threading.Thread(target=self._install_newest_worker, daemon=True).start()

    def _install_newest_worker(self):
        try:
            releases = self.fetch_releases()
            if not releases:
                raise RuntimeError("No release with setup EXE/MSI was found.")
            self.install_release(releases[0])
            self.signals.install_done.emit(releases[0].display_name())
            self.signals.releases_loaded.emit(releases)
        except Exception:
            self.signals.error.emit(traceback.format_exc())
            self.signals.releases_loaded.emit(self.releases)

    def install_older_release(self):
        release = self.older_combo.currentData()
        if not isinstance(release, ReleaseInfo):
            QMessageBox.warning(self, "Auto Updater", "Please select an older release first.")
            return
        self.set_busy(True)
        threading.Thread(target=self._install_release_worker, args=(release,), daemon=True).start()

    def _install_release_worker(self, release: ReleaseInfo):
        try:
            self.install_release(release)
            self.signals.install_done.emit(release.display_name())
        except Exception:
            self.signals.error.emit(traceback.format_exc())
        finally:
            self.signals.releases_loaded.emit(self.releases)

    def install_release(self, release: ReleaseInfo):
        if not release.asset_url:
            raise RuntimeError("The selected release has no setup asset.")
        downloads = self.base / "_mustatil_update_downloads"
        downloads.mkdir(exist_ok=True)
        filename = release.asset_name or f"Mustatil_Setup_{release.tag or 'release'}.exe"
        target = downloads / self.safe_filename(filename)
        self.signals.log.emit(f"Download: {release.display_name()}")
        self.download_file(release.asset_url, target)
        self.signals.log.emit(f"Starting setup: {target.name}")
        self.run_installer(target)

    def safe_filename(self, name: str) -> str:
        bad = '<>:"/\\|?*'
        out = ''.join('_' if c in bad else c for c in name).strip()
        return out or "Mustatil_Setup.exe"

    def download_file(self, url: str, target: Path):
        req = urllib.request.Request(url, headers={"User-Agent": "MustatilAutoUpdater/1.0"})
        with urllib.request.urlopen(req, timeout=60) as resp, target.open("wb") as f:
            total = int(resp.headers.get("Content-Length") or 0)
            done = 0
            last_log = 0
            while True:
                chunk = resp.read(1024 * 1024)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                now = time.time()
                if total and now - last_log > 1.0:
                    self.signals.log.emit(f"Download: {done * 100 // total}%")
                    last_log = now

    def run_installer(self, path: Path):
        """Run the downloaded installer automatically and create a desktop shortcut afterwards."""
        if not sys.platform.startswith("win"):
            subprocess.Popen([str(path)], cwd=str(path.parent))
            return

        suffix = path.suffix.lower()
        if suffix == ".msi":
            cmd = ["msiexec.exe", "/i", str(path), "/qn", "/norestart"]
            self.signals.log.emit("Starting MSI automatically/silently …")
            proc = subprocess.Popen(cmd, cwd=str(path.parent))
            proc.wait()
        else:
            cmd = [str(path)] + SILENT_INNO_ARGS
            self.signals.log.emit("Starting EXE automatically/silently …")
            proc = subprocess.Popen(cmd, cwd=str(path.parent))
            proc.wait()

            # Some installers are NSIS and need /S instead of Inno parameters.
            if proc.returncode not in (0, None):
                self.signals.log.emit(f"Silent start with Inno parameters returned code {proc.returncode}. Trying /S …")
                proc2 = subprocess.Popen([str(path)] + SILENT_NSIS_ARGS, cwd=str(path.parent))
                proc2.wait()

        self.create_desktop_shortcut()

    def desktop_dir(self) -> Path:
        userprofile = os.environ.get("USERPROFILE")
        if userprofile:
            return Path(userprofile) / "Desktop"
        return Path.home() / "Desktop"

    def find_shortcut_target(self) -> Optional[Path]:
        candidates = [
            self.base / "launcher.bat",
            self.base / "START_MUSTATIL_QT_WORKSPACE.bat",
            self.base / "Mustatil.bat",
            self.base / "Mustatil.exe",
            self.base / "mustatil_qt_workspace.exe",
            self.base / "mustatil_qt_workspace.py",
        ]
        for c in candidates:
            if c.exists():
                return c

        local_appdata = os.environ.get("LOCALAPPDATA")
        if local_appdata:
            install_base = Path(local_appdata) / "Programs" / "Mustatil"
            for name in ("launcher.bat", "START_MUSTATIL_QT_WORKSPACE.bat", "Mustatil.exe", "mustatil_qt_workspace.py"):
                c = install_base / name
                if c.exists():
                    return c
        return None

    def create_desktop_shortcut(self):
        if not sys.platform.startswith("win"):
            return
        target = self.find_shortcut_target()
        if not target:
            self.signals.log.emit("Desktop shortcut not created: launcher/start file was not found.")
            return

        desktop = self.desktop_dir()
        desktop.mkdir(parents=True, exist_ok=True)
        shortcut = desktop / "Mustatil.lnk"
        icon = target

        ps = "\n".join([
            "$WshShell = New-Object -ComObject WScript.Shell",
            f"$Shortcut = $WshShell.CreateShortcut({str(shortcut)!r})",
            f"$Shortcut.TargetPath = {str(target)!r}",
            f"$Shortcut.WorkingDirectory = {str(target.parent)!r}",
            f"$Shortcut.IconLocation = {str(icon)!r}",
            "$Shortcut.Save()",
        ])
        try:
            subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps], check=True, capture_output=True, text=True)
            self.signals.log.emit(f"Desktop shortcut created: {shortcut}")
        except Exception as exc:
            self.signals.log.emit(f"Desktop shortcut could not be created: {exc}")

    def on_install_done(self, release_name: str):
        self.log(f"Installer executed automatically: {release_name}")
        QMessageBox.information(self, "Auto Updater", "Setup was executed automatically. A desktop shortcut is created if a launcher/start file is found.")


def main():
    app = QApplication(sys.argv)
    w = AutoUpdaterWindow()
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
