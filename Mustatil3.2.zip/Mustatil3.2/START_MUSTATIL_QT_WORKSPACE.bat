@echo off
setlocal
title Start Mustatil Qt Workspace

cd /d "%~dp0"

echo ============================================================
echo Starting Mustatil Qt Workspace
echo ============================================================
echo.

if not exist ".venv\Scripts\python.exe" (
    echo ERROR: Local virtual environment not found:
    echo   %CD%\.venv\Scripts\python.exe
    echo.
    echo Please run INSTALL_MUSTATIL_DEPENDENCIES_PY312.bat first.
    echo.
    pause
    exit /b 1
)

if not exist "mustatil_qt_workspace.py" (
    echo ERROR: mustatil_qt_workspace.py was not found in this folder:
    echo   %CD%
    echo.
    echo Put this BAT in the same folder as mustatil_qt_workspace.py.
    echo.
    pause
    exit /b 1
)

echo Using Python:
".venv\Scripts\python.exe" --version
echo.

echo Starting GUI...
echo.

".venv\Scripts\python.exe" "mustatil_qt_workspace.py"

set EXITCODE=%ERRORLEVEL%
echo.
echo ============================================================
echo Program closed with exit code %EXITCODE%
echo ============================================================
echo.
pause
exit /b %EXITCODE%
