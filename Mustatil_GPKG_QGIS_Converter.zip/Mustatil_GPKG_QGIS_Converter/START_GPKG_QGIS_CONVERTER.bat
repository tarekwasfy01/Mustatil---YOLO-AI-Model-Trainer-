@echo off
setlocal
title Start - Mustatil GPKG QGIS Converter

cd /d "%~dp0"

echo ============================================================
echo Start - Mustatil GPKG QGIS Converter
echo ============================================================
echo.

set "VENV_PY=%~dp0.venv\Scripts\python.exe"
set "SCRIPT=%~dp0gpkg_qgis_converter_gui.py"

if not exist "%SCRIPT%" (
    echo ERROR: Converter script not found:
    echo %SCRIPT%
    echo.
    pause
    exit /b 1
)

if not exist "%VENV_PY%" (
    echo ERROR: Local Python environment was not found.
    echo Please run INSTALL_DEPENDENCIES.bat first.
    echo.
    pause
    exit /b 1
)

echo Checking dependencies...
"%VENV_PY%" -c "import geopandas, pyproj, shapely, fiona, pyogrio; print('Dependencies OK')"
if errorlevel 1 (
    echo.
    echo ERROR: Dependencies are missing or broken.
    echo Please run INSTALL_DEPENDENCIES.bat again.
    echo.
    pause
    exit /b 1
)

echo.
echo Starting GUI...
echo.
"%VENV_PY%" "%SCRIPT%"

echo.
echo Program closed.
pause
endlocal
