@echo off
setlocal
title Install Dependencies - Mustatil GPKG QGIS Converter

cd /d "%~dp0"

echo ============================================================
echo Install Dependencies - Mustatil GPKG QGIS Converter
echo ============================================================
echo.
echo This will create/use a local .venv folder next to this BAT.
echo It tries Python 3.11 first, then Python 3.12.
echo.

set "PYTHON_CMD="

py -3.11 --version >nul 2>&1
if not errorlevel 1 (
    set "PYTHON_CMD=py -3.11"
    goto :python_found
)

py -3.12 --version >nul 2>&1
if not errorlevel 1 (
    set "PYTHON_CMD=py -3.12"
    goto :python_found
)

echo ERROR: Python 3.11 or 3.12 was not found.
echo Please install Python 3.11 recommended or Python 3.12 from:
echo https://www.python.org/downloads/
echo.
pause
exit /b 1

:python_found
echo Using:
%PYTHON_CMD% --version
echo.

set "VENV_DIR=%~dp0.venv"

if not exist "%VENV_DIR%\Scripts\python.exe" (
    echo Creating virtual environment:
    echo %VENV_DIR%
    %PYTHON_CMD% -m venv "%VENV_DIR%"
    if errorlevel 1 (
        echo.
        echo ERROR: Could not create virtual environment.
        pause
        exit /b 1
    )
) else (
    echo Existing virtual environment found.
)

echo.
echo Upgrading pip/setuptools/wheel...
"%VENV_DIR%\Scripts\python.exe" -m pip install -U pip setuptools wheel
if errorlevel 1 (
    echo.
    echo ERROR: pip upgrade failed.
    pause
    exit /b 1
)

echo.
echo Installing GeoPandas stack...
echo This may take a while on the first run.
"%VENV_DIR%\Scripts\python.exe" -m pip install --only-binary=:all: geopandas pyproj shapely fiona pyogrio rtree pandas numpy
if errorlevel 1 (
    echo.
    echo Binary install failed. Trying normal pip install...
    "%VENV_DIR%\Scripts\python.exe" -m pip install geopandas pyproj shapely fiona pyogrio rtree pandas numpy
    if errorlevel 1 (
        echo.
        echo ERROR: Dependency installation failed.
        echo.
        echo Possible fix:
        echo 1. Install Python 3.11 from python.org
        echo 2. Delete the .venv folder
        echo 3. Run this BAT again
        echo.
        pause
        exit /b 1
    )
)

echo.
echo Testing imports...
"%VENV_DIR%\Scripts\python.exe" -c "import geopandas as gpd, pyproj, shapely, fiona, pyogrio; print('GeoPandas OK:', gpd.__version__); print('PyProj OK:', pyproj.__version__); print('Shapely OK:', shapely.__version__); print('Fiona OK:', fiona.__version__); print('Pyogrio OK:', pyogrio.__version__)"
if errorlevel 1 (
    echo.
    echo ERROR: Import test failed.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo Dependencies installed successfully.
echo Now run START_GPKG_QGIS_CONVERTER.bat
echo ============================================================
pause
endlocal
