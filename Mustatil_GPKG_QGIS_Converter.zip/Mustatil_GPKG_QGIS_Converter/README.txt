Mustatil GPKG QGIS Converter
============================

Inhalt:
- gpkg_qgis_converter_gui.py
- INSTALL_DEPENDENCIES.bat
- START_GPKG_QGIS_CONVERTER.bat

Benutzung:
1. ZIP entpacken.
2. INSTALL_DEPENDENCIES.bat doppelklicken.
3. Danach START_GPKG_QGIS_CONVERTER.bat doppelklicken.
4. In der GUI deine problematische .gpkg wählen.
5. "Convert to QGIS GeoPackage" klicken.
6. Die neue *_qgis.gpkg in QGIS laden.

Hinweise:
- Python 3.11 wird bevorzugt.
- Falls Python 3.11 nicht installiert ist, versucht die BAT Python 3.12.
- Die Abhängigkeiten werden in einer lokalen .venv im Ordner installiert.
- Dein normales Windows-Python wird dadurch nicht verändert.
