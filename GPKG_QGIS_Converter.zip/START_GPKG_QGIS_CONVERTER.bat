@echo off
title GeoPackage QGIS Converter

cd /d "C:\Users\tarek\Desktop"

if exist "dml_env\Scripts\python.exe" (
    set PYEXE=C:\Users\tarek\Desktop\dml_env\Scripts\python.exe
) else if exist "onnx314_env\Scripts\python.exe" (
    set PYEXE=C:\Users\tarek\Desktop\onnx314_env\Scripts\python.exe
) else (
    set PYEXE=python
)

echo Using Python: %PYEXE%
echo.
echo Installing/checking converter dependencies...
"%PYEXE%" -m pip install geopandas fiona shapely pyproj

echo.
echo Starting GeoPackage QGIS Converter...
"%PYEXE%" "C:\Users\tarek\Desktop\gpkg_qgis_converter_gui.py"

pause
