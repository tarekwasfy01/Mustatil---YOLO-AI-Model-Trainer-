@echo off
setlocal
cd /d "%~dp0"
title Install Mustatil dependencies

echo ============================================================
echo Installing Mustatil GUI dependencies for Python 3.11
echo ============================================================

where py >nul 2>nul
if %errorlevel%==0 (
    set PY=py -3.11
) else (
    set PY=python
)

%PY% --version
if errorlevel 1 (
    echo Python was not found. Install Python 3.11 and enable PATH.
    pause
    exit /b 1
)

echo.
echo Upgrading pip...
%PY% -m pip install --upgrade pip setuptools wheel

echo.
echo Installing core packages...
%PY% -m pip install pillow numpy pyyaml opencv-python tqdm pandas

echo.
echo Installing Torch CPU packages...
%PY% -m pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu

echo.
echo Installing Ultralytics and ONNX Runtime...
%PY% -m pip install ultralytics onnx onnxruntime onnxruntime-directml lap pyinstaller pyinstaller-hooks-contrib

echo.
echo Optional GeoTIFF support. Rasterio wheels are usually available for Python 3.11.
%PY% -m pip install rasterio shapely

echo.
echo Done.
pause
